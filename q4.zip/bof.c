#include <stdio.h>
#include <stdlib.h>

void func(char *str) {
	char buf[256];
	printf("address: %p\n", buf);
	gets(buf);
}

int main(int argc, char *argv[]) {
	func(argv[1]);
	return EXIT_SUCCESS;
}
