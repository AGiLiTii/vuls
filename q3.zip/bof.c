#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void func(char *str) {
	char buf[256];
	strcpy(buf, str);
}

int main(int argc, char *argv[]) {

	if (argc != 2) {
		printf("Argument required.\n");
		return EXIT_FAILURE;
	}

	func(argv[1]);
	printf("Let this line disappear.\n");

	return EXIT_SUCCESS;
}
